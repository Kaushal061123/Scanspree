
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Side Navigation Bar</title>
	<link rel="stylesheet" href="style2.css">

</head>
<body>

<div class="wrapper">
    <div class="sidebar">
    <img src="images/ss.png" alt="ScanSpree" width="180" height="80" class="d-inline-block align-text-top">
        
        <ul>
            <li><a href="#"><i class="fas fa-home"></i>Products</a></li>
            <li><a href="#"><i class="fas fa-user"></i>Users</a></li>
            <li><a href="#"><i class="fas fa-address-card"></i>Order List</a></li>
            <li><a href="#"><i class="fas fa-project-diagram"></i>Carts</a></li>
            <li><a href="#"><i class="fas fa-blog"></i>Revenue</a></li>
            <li><a href="#"><i class="fas fa-address-book"></i>Logout</a></li>
            
        </ul> 
        
    </div>
    <div class="main_content">
           
    </div>
</div>

</body>
</html>
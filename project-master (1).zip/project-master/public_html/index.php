<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="refresh" content="5;URL=homepg.php">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="style1.css">
    <!--<style>
        body{
            background-image: url('images/bg.png');
            background-size: auto;
            background-repeat: no-repeat;
            height: auto;
            max-width: 100%;
        }
    </style>-->
    <style>
        <?php include "style1.css" ?>
    </style>
</head>
<body>
    <div class="container-fluid" id="index" scroll="no">

    <div class="container1">
            <div class="center">
               <img src="Images\ss.png" alt="ScanSpree" width="280px" height="30%" class="d-inline-block align-text-top" !important>
            </div>
        </div>

        <div class="row fixed-top" id="top">
            
        <div class="col" id="t1"><img src="Images/gra4.svg"  width="160px" height="100%"  ></div>
        </div>


        <div class="row fixed-bottom" id="bottom">
            
            <div class="col" id="t2"><img src="Images/g2.svg" width="200px" height="100%" ></div>
        </div>
            
    </div>
        
            
    
    
</body>
</html>